/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HomeData, PageId } from '../../types';
import { calculateCountdown, CountdownResult } from '../../utils/logic';
import { PageFlowNext } from '../PageFlowNext';
import { ArrowRight, Bell, Calendar, Clock, Edit2, Landmark, Users } from 'lucide-react';

interface HomeViewProps {
  data: HomeData;
  isAdmin: boolean;
  onNavigate: (page: PageId) => void;
  onEditSection: (sectionKey: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  data,
  isAdmin,
  onNavigate,
  onEditSection,
}) => {
  const [countdown, setCountdown] = useState<CountdownResult>(() =>
    calculateCountdown(data.eventDate)
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(calculateCountdown(data.eventDate));
    }, 1000);
    return () => clearInterval(timer);
  }, [data.eventDate]);

  return (
    <div className="space-y-16">
      {/* News Ticker */}
      <div className="border-y border-[#E5E0D8] bg-[#FAF8F5] py-2.5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-3 w-full">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-[#1F3D33] text-[#FAF8F5] text-xs uppercase tracking-wider font-semibold rounded-xs shrink-0">
              <Bell className="w-3 h-3 text-[#B08D57]" />
              <span>Gazette Bulletin</span>
            </div>
            <div className="overflow-hidden relative w-full">
              <div className="text-sm font-medium text-[#2B2B2B] whitespace-nowrap animate-marquee">
                {data.newsTicker}
              </div>
            </div>
          </div>
          {isAdmin && (
            <button
              onClick={() => onEditSection('home.newsTicker')}
              className="ml-3 text-xs text-[#B08D57] hover:text-[#1F3D33] flex items-center gap-1 shrink-0 cursor-pointer"
              title="Edit Ticker"
            >
              <Edit2 className="w-3 h-3" />
              <span>Edit</span>
            </button>
          )}
        </div>
      </div>

      {/* Hero Section */}
      <section className="text-center pt-8 pb-4 relative">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-sm border border-[#E5E0D8] bg-[#FAF8F5] text-xs font-medium uppercase tracking-widest text-[#1F3D33] mb-6">
          <Calendar className="w-3.5 h-3.5 text-[#B08D57]" />
          <span>{data.eventTimeDisplay}</span>
        </div>

        <h1 className="font-heading text-4xl sm:text-6xl md:text-7xl font-bold text-[#1F3D33] tracking-tight max-w-4xl mx-auto leading-[1.08] mb-6">
          {data.heroHeading}
        </h1>

        <div className="flex items-center justify-center space-x-3 text-xl sm:text-2xl font-serif text-[#B08D57] italic tracking-wide mb-8">
          <span>{data.heroTagline}</span>
        </div>

        {/* Vision Line */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-[#6B6B6B] leading-relaxed mb-10">
          &quot;{data.visionLine}&quot;
        </p>

        {/* Countdown Timer */}
        <div className="max-w-xl mx-auto card-subtle p-6 rounded-sm mb-12 border border-[#E5E0D8]">
          <div className="flex items-center justify-center space-x-2 text-xs uppercase tracking-widest text-[#1F3D33] font-semibold mb-4">
            <Clock className="w-4 h-4 text-[#B08D57]" />
            <span>Parliament Convening Countdown</span>
          </div>

          <div className="grid grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-[#FAF8F5] border border-[#E5E0D8] rounded-xs">
              <span className="block font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
                {String(countdown.days).padStart(2, '0')}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#6B6B6B] font-medium">
                Days
              </span>
            </div>
            <div className="p-3 bg-[#FAF8F5] border border-[#E5E0D8] rounded-xs">
              <span className="block font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
                {String(countdown.hours).padStart(2, '0')}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#6B6B6B] font-medium">
                Hours
              </span>
            </div>
            <div className="p-3 bg-[#FAF8F5] border border-[#E5E0D8] rounded-xs">
              <span className="block font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
                {String(countdown.minutes).padStart(2, '0')}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#6B6B6B] font-medium">
                Mins
              </span>
            </div>
            <div className="p-3 bg-[#FAF8F5] border border-[#E5E0D8] rounded-xs">
              <span className="block font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
                {String(countdown.seconds).padStart(2, '0')}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#6B6B6B] font-medium">
                Secs
              </span>
            </div>
          </div>
        </div>

        {/* 3 Stats Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto border-y border-[#E5E0D8] py-8">
          <div className="text-center sm:border-r border-[#E5E0D8] sm:pr-4">
            <div className="font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
              {data.stats.stat1}
            </div>
            <div className="text-xs uppercase tracking-widest text-[#6B6B6B] font-medium mt-1">
              {data.stats.label1}
            </div>
          </div>
          <div className="text-center sm:border-r border-[#E5E0D8] sm:pr-4">
            <div className="font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
              {data.stats.stat2}
            </div>
            <div className="text-xs uppercase tracking-widest text-[#6B6B6B] font-medium mt-1">
              {data.stats.label2}
            </div>
          </div>
          <div className="text-center">
            <div className="font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33]">
              {data.stats.stat3}
            </div>
            <div className="text-xs uppercase tracking-widest text-[#6B6B6B] font-medium mt-1">
              {data.stats.label3}
            </div>
          </div>
        </div>
      </section>

      {/* Two HUGE Boxes side by side (stack on mobile) */}
      <section className="pt-6">
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs font-semibold tracking-widest uppercase text-[#B08D57]">
            Deliberative Houses
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#1F3D33] mt-1">
            Choose a Parliamentary Chamber
          </h2>
          <p className="text-sm text-[#6B6B6B] mt-2">
            Explore the specialized mandates, agendas, and procedural session flows for both committees.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {/* Box 1 — LOK SABHA */}
          <div className="card-subtle p-8 sm:p-10 rounded-sm border border-[#E5E0D8] flex flex-col justify-between hover:border-[#1F3D33] transition-all duration-300 relative group">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-2.5 py-1 text-xs font-semibold uppercase tracking-wider bg-[#1F3D33]/10 text-[#1F3D33] rounded-xs border border-[#1F3D33]/20">
                  {data.lokSabhaBox.themeBadge}
                </span>
                <Landmark className="w-6 h-6 text-[#1F3D33]/70 group-hover:text-[#1F3D33] transition-colors" />
              </div>

              <h3 className="font-heading text-3xl sm:text-5xl font-bold text-[#1F3D33] mb-2">
                {data.lokSabhaBox.title}
              </h3>
              <p className="text-xs text-[#6B6B6B] font-medium uppercase tracking-wider mb-6">
                {data.lokSabhaBox.subtitle}
              </p>

              <div className="p-4 bg-[#FAF8F5] border-l-2 border-[#1F3D33] mb-8">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-[#1F3D33] mb-1">
                  Official Agenda
                </span>
                <p className="text-sm text-[#2B2B2B] leading-relaxed">
                  {data.lokSabhaBox.agendaText}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E5E0D8] flex items-center justify-between">
              <button
                onClick={() => onNavigate('agendas')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#1F3D33] hover:bg-[#162c25] text-[#FAF8F5] text-sm font-medium rounded-sm transition-colors cursor-pointer group-hover:bg-[#162c25]"
                aria-label="View Lok Sabha Agenda"
              >
                <span>View Agenda →</span>
                <ArrowRight className="w-4 h-4 text-[#B08D57]" />
              </button>

              {isAdmin && (
                <button
                  onClick={() => onEditSection('home.lokSabhaBox')}
                  className="text-xs text-[#6B6B6B] hover:text-[#1F3D33] p-1 cursor-pointer flex items-center gap-1"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Box</span>
                </button>
              )}
            </div>
          </div>

          {/* Box 2 — AIPPM */}
          <div className="card-subtle p-8 sm:p-10 rounded-sm border border-[#E5E0D8] flex flex-col justify-between hover:border-[#B08D57] transition-all duration-300 relative group">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-2.5 py-1 text-xs font-semibold uppercase tracking-wider bg-[#B08D57]/15 text-[#8b6932] rounded-xs border border-[#B08D57]/30">
                  {data.aippmBox.themeBadge}
                </span>
                <Users className="w-6 h-6 text-[#B08D57] group-hover:text-[#8b6932] transition-colors" />
              </div>

              <h3 className="font-heading text-3xl sm:text-5xl font-bold text-[#1F3D33] mb-2">
                {data.aippmBox.title}
              </h3>
              <p className="text-xs text-[#6B6B6B] font-medium uppercase tracking-wider mb-6">
                {data.aippmBox.subtitle}
              </p>

              <div className="p-4 bg-[#FAF8F5] border-l-2 border-[#B08D57] mb-8">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-[#8b6932] mb-1">
                  Official Agenda
                </span>
                <p className="text-sm text-[#2B2B2B] leading-relaxed">
                  {data.aippmBox.agendaText}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E5E0D8] flex items-center justify-between">
              <button
                onClick={() => onNavigate('agendas')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#1F3D33] hover:bg-[#162c25] text-[#FAF8F5] text-sm font-medium rounded-sm transition-colors cursor-pointer"
                aria-label="View AIPPM Agenda"
              >
                <span>View Agenda →</span>
                <ArrowRight className="w-4 h-4 text-[#B08D57]" />
              </button>

              {isAdmin && (
                <button
                  onClick={() => onEditSection('home.aippmBox')}
                  className="text-xs text-[#6B6B6B] hover:text-[#1F3D33] p-1 cursor-pointer flex items-center gap-1"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Box</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Page Flow: Next link to About */}
      <PageFlowNext currentPage="home" onNavigate={onNavigate} />
    </div>
  );
};
